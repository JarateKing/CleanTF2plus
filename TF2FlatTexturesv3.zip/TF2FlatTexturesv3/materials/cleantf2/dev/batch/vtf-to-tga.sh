#!/bin/sh 

wine dev/VTFCmd.exe -file $1 -exportformat "tga"
