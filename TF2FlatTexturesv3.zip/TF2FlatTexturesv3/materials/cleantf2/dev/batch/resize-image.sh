#!/bin/sh

convert $1 -resize $2x$2 $1
