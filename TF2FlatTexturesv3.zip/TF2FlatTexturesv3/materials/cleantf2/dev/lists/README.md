# dev/lists

This folder contains lists of files and folders from the tf2 vpk's, to be passed into the generator scripts
